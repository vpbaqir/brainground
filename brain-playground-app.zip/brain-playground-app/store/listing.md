# Store listing text (edit the [brackets])

## App name (max 30 chars)
Brain Playground

## Short description (Google, max 80 chars)
20 brain games for curious kids: logic, memory, maths, words. No ads, no tracking.

## Full description (English)
Brain Playground is a calm, colorful playground of 20 short brain games for curious children (ages 6-12).

GAMES THAT GROW WITH YOUR CHILD
Reasoning: Pattern detective, Logic clues, Shape sequence, Balance scale, Odd word out
Memory: Echo, Memory match, Digit flash, What is missing, Backwards echo
Maths: Number chef, Speed sums, Make the target, Greater or less
Focus: Sharp eye, Colour clash, Count flash
Language: Word builder, Missing letter (English, Malayalam, Arabic)
Spatial: Mirror match

WHY CHILDREN COME BACK
Every game is 5 short rounds. Difficulty adapts from level 1 to 10. Stars, badges, a daily challenge and a day streak make coming back fun.

PARENTS STAY IN CONTROL
A PIN-locked Parent corner shows progress across six brain skills. No accounts. No data collected. Works offline. Progress stays on the device.

Contains small, clearly labelled sponsor logos. No ad networks. No tracking.

## Malayalam short description
കുട്ടികൾക്കായി 20 ബ്രെയിൻ ഗെയിമുകൾ: യുക്തി, ഓർമ്മ, കണക്ക്, വാക്കുകൾ. പരസ്യമില്ല, ട്രാക്കിങ്ങില്ല.

## Arabic short description
٢٠ لعبة ذكاء للأطفال الفضوليين: منطق وذاكرة وحساب وكلمات. بدون إعلانات وبدون تتبع.

## Categories and ratings
- Google Play: Education. Target age groups: 6-8 and 9-12. Do not select "Ages 5 & under".
- Apple: Education (primary). Decide on Kids Category: stricter rules, "for kids" wording allowed only there.
- Age rating questionnaire (IARC / Apple): no violence, no user-generated content, no chat, no purchases, no gambling.

## Google Play "Data safety" answers
- Does the app collect or share user data? No.
- Data encrypted in transit: Yes (HTTPS for sponsor list only).
- Users can request deletion: yes, Reset progress in app, or uninstall.
- Contains ads: Yes (sponsor logos, direct, no ad SDK).
- Families: app is for children and mixed audience. No AD_ID permission. No location.

## Apple "App Privacy" answers
- Data collected: None. Tracking: No.

## Screenshots to take (phone, 1080x1920 or larger)
1. Home with daily challenge 2. A pattern game 3. Echo pads 4. Word builder in Malayalam 5. Rewards badges 6. Parent corner progress
(Also tablet shots: Apple needs iPad sizes if the app runs on iPad. Play needs 7" and 10" shots for tablet listing.)
