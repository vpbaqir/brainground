# Brain Playground: store build

Folder map: `www/` the app (HTML, fonts). `android/` and `ios/` native projects (Capacitor). `assets/` icon + splash sources. `store/` privacy page and listing text. `.github/workflows/android.yml` cloud Android build. `codemagic.yaml` cloud iOS build.

## 0. Before anything
1. Edit `www/index.html`, find `const CFG=`: set `PRIVACY_URL` (your hosted privacy page) and later `SPONSORS_URL` (your hosted `sponsors.json`).
2. Edit `store/privacy.html`: fill [brackets]. Host it (GitHub Pages is free). Put the URL in `PRIVACY_URL`.
3. Pick your app ID (reverse domain). Default is `com.brainplayground.app`. Change it in `capacitor.config.json`, `android/app/build.gradle` (applicationId, namespace) and `codemagic.yaml` BEFORE first upload. It cannot change later.
4. Run: `npm install` then `npx cap sync`.

## 1. Android (Google Play)
- Create a Google Play developer account (one-time fee; check price). Personal accounts made after 13 Nov 2023 need a closed test with 12 testers for 14 days before production. Organization accounts skip this.
- Make a signing key once and BACK IT UP in two places: `keytool -genkey -v -keystore release.jks -alias brain -keyalg RSA -keysize 2048 -validity 10000`
- Build the AAB, either:
  - Android Studio: `npx cap open android` then Build > Generate Signed Bundle, or
  - GitHub: push this folder to a private repo, add secrets KEYSTORE_B64 (`base64 -w0 release.jks`), KS_PASS, KEY_ALIAS, KEY_PASS, run the "Android release bundle" workflow, download the .aab.
- Play Console: create app, Education, upload AAB to Closed testing, add 12 testers, fill App content: Target audience (6-8, 9-12), Data safety, Ads = yes, Privacy policy URL. Use `store/listing.md`.
- Check that the build asks for no permissions: open `android/app/src/main/AndroidManifest.xml`. Only INTERNET should appear. Do not add AD_ID.
- Target API: if Play Console warns the target level is too old, raise `targetSdkVersion` in `android/variables.gradle`.

## 2. iOS (App Store)
- Apple Developer Program (yearly fee; check price). Need a Mac, or Codemagic (cloud Mac).
- In App Store Connect create the app with the same bundle ID. Create an API key and connect it in Codemagic as `BrainPlaygroundKey`.
- Run the `ios-release` workflow. It uploads to TestFlight. Test on a real iPhone/iPad, then submit for review.
- Reviewer notes to paste: "Offline educational games. No accounts, no tracking, no third-party ads or analytics. Sponsor logos are static and not tappable by children. Sponsor links are only inside a PIN-protected Parent corner."
- Apple may reject apps that feel like a plain website (Guideline 4.2). This app is fully offline with native splash and icon. If asked, point to the 20 games and offline use.

## 3. Sponsors without republishing
Host `sponsors.json` anywhere with HTTPS. Format:
{"sponsors":[{"n":"Shop name","t":"One short line","c":"#A8E6BC","l":"data:image/png;base64,....(small logo, under 8KB)","u":"https://shop.example","s":["home","result","parent"],"a":"2026-11-01","z":"2026-12-31"}]}
Rules built in: max 8, https links only, image logos only, bad entries are ignored. Set `SPONSORS_URL` in `www/index.html`, run `npx cap sync`, release a new version once. After that, edit the JSON file and all devices update on next open.

## 4. Each update
Raise `VERSION` in CFG, `versionCode` and `versionName` in `android/app/build.gradle`, and the iOS build number. Then build and upload again.

## Not legal advice
Child-privacy law (India DPDP Act, US COPPA) and store rules change. Check current store policies before each submission and ask a lawyer before taking sponsor money.
